const { 
    EmbedBuilder, 
    ActionRowBuilder, 
    ButtonBuilder, 
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    PermissionFlagsBits
} = require('discord.js');
const fs = require('fs/promises');
const path = require('path');

class AdvancedSettingsHandler {
    constructor() {
        this.CONFIG_PATH = path.join(__dirname, 'settings.json');
    }

    async readConfig() {
        try {
            const data = await fs.readFile(this.CONFIG_PATH, 'utf8');
            return JSON.parse(data);
        } catch (error) {
            console.error('Erro ao ler configurações:', error);
            return null;
        }
    }

    async writeConfig(config) {
        try {
            await fs.writeFile(this.CONFIG_PATH, JSON.stringify(config, null, 2), 'utf8');
            return true;
        } catch (error) {
            console.error('Erro ao salvar configurações:', error);
            return false;
        }
    }

    hasAdminRole(member, adminRoleId) {
        const hasRole = member.roles.cache.has(adminRoleId);
        if (!hasRole) {
            console.log(`Acesso negado para ${member.user.tag} - Cargo ADMIN requerido`);
        }
        return hasRole;
    }

    async handleAdvancedButton(interaction) {
        const config = await this.readConfig();
        if (!config) {
            return await interaction.reply({
                content: '❌ Erro ao carregar as configurações.',
                ephemeral: true
            });
        }

        if (!config.ROLES?.ADMIN) {
            return await interaction.reply({
                content: '❌ Cargo ADMIN não configurado no sistema.',
                ephemeral: true
            });
        }

        if (!this.hasAdminRole(interaction.member, config.ROLES.ADMIN)) {
            return await interaction.reply({
                content: '❌ Você precisa ter o cargo ADMIN para acessar essas configurações.',
                ephemeral: true
            });
        }

        const embed = new EmbedBuilder()
            .setTitle('⚙️ Configurações Avançadas')
            .setDescription('Gerencie os IDs dos canais e cargos do sistema para aparecer os ids aqui feche e abre novamente o menu de configurações.')
            .setColor(0xFF0000)
            .addFields(
                { name: 'Canal de Logs', value: `ID: ${config.CHANNELS.LOGS}`, inline: true },
                { name: 'Canal de Lembretes', value: `ID: ${config.CHANNELS.REMINDER}`, inline: true },
                { name: 'Cargo de Admin', value: `ID: ${config.ROLES.ADMIN}`, inline: true }
            )
            .setTimestamp();

        const row = new ActionRowBuilder()
            .addComponents(
                new ButtonBuilder()
                    .setCustomId('edit_logs')
                    .setLabel('Editar Canal de Logs')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('edit_reminder')
                    .setLabel('Editar Canal de Lembretes')
                    .setStyle(ButtonStyle.Primary),
                new ButtonBuilder()
                    .setCustomId('edit_admin_role')
                    .setLabel('Editar Cargo Admin')
                    .setStyle(ButtonStyle.Secondary)
            );

        await interaction.reply({
            embeds: [embed],
            components: [row],
            ephemeral: true
        });
    }

    async handleEditButtons(interaction) {
        const config = await this.readConfig();
        if (!config?.ROLES?.ADMIN) return;

        if (!this.hasAdminRole(interaction.member, config.ROLES.ADMIN)) {
            return await interaction.reply({
                content: '❌ Acesso negado.',
                ephemeral: true
            });
        }

        const type = interaction.customId.split('_')[1];
        const isRole = type === 'admin';
        
        const modal = new ModalBuilder()
            .setCustomId(`modal_${type}`)
            .setTitle(
                type === 'logs' ? 'Editar Canal de Logs' : 
                type === 'reminder' ? 'Editar Canal de Lembretes' : 
                'Editar Cargo Admin'
            );

        const input = new TextInputBuilder()
            .setCustomId('id_input')
            .setLabel(`Novo ID do ${isRole ? 'Cargo' : 'Canal'}`)
            .setStyle(TextInputStyle.Short)
            .setPlaceholder(`Digite o ID do novo ${isRole ? 'cargo' : 'canal'}`)
            .setRequired(true);

        const actionRow = new ActionRowBuilder().addComponents(input);
        modal.addComponents(actionRow);

        await interaction.showModal(modal);
    }

    async handleModalSubmit(interaction) {
        const config = await this.readConfig();
        if (!config?.ROLES?.ADMIN) return;

        if (!this.hasAdminRole(interaction.member, config.ROLES.ADMIN)) {
            return await interaction.reply({
                content: '❌ Acesso negado.',
                ephemeral: true
            });
        }

        const type = interaction.customId.split('_')[1];
        const newId = interaction.fields.getTextInputValue('id_input');

        try {
            if (type === 'admin') {
                const role = await interaction.guild.roles.fetch(newId);
                if (!role) throw new Error('Cargo não encontrado');
                config.ROLES.ADMIN = newId;
            } else {
                const channel = await interaction.guild.channels.fetch(newId);
                if (!channel) throw new Error('Canal não encontrado');
                config.CHANNELS[type.toUpperCase()] = newId;
            }
            
            const success = await this.writeConfig(config);
            if (!success) throw new Error('Erro ao salvar configurações');

            await interaction.reply({
                content: `✅ ${type === 'admin' ? 'Cargo Admin' : 'Canal'} atualizado com sucesso!`,
                ephemeral: true
            });
        } catch (error) {
            await interaction.reply({
                content: `❌ Erro ao atualizar. Verifique se o ID é válido.`,
                ephemeral: true
            });
        }
    }
}


const handler = new AdvancedSettingsHandler();
module.exports = handler;