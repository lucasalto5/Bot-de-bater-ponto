const { EmbedBuilder } = require('discord.js');
const fs = require('fs/promises');
const path = require('path');

class ActivityLogger {
    constructor(client) {
        this.client = client;
        this.configPath = path.join(__dirname, 'settings.json');
        this.logChannelId = null;
        this.initialize();
    }

    async initialize() {
        try {
            const config = await this.readConfig();
            this.logChannelId = config.CHANNELS.LOGS;
        } catch (error) {
            console.error('Erro ao inicializar logger:', error);
        }
    }

    async readConfig() {
        const data = await fs.readFile(this.configPath, 'utf8');
        return JSON.parse(data);
    }

    async updateLogChannel() {
        try {
            const config = await this.readConfig();
            this.logChannelId = config.CHANNELS.LOGS;
        } catch (error) {
            console.error('Erro ao atualizar canal de logs:', error);
        }
    }

    async sendLog(embed) {
        try {

            await this.updateLogChannel();
            
            const logChannel = await this.client.channels.fetch(this.logChannelId);
            if (logChannel) {
                await logChannel.send({ embeds: [embed] });
            } else {
                throw new Error('Canal de logs não encontrado');
            }
        } catch (error) {
            console.error('Erro ao enviar log:', error);

            console.error({
                error: error.message,
                channelId: this.logChannelId,
                timestamp: new Date().toISOString()
            });
        }
    }

    async logEntry(userId, entryTime) {
        const embed = new EmbedBuilder()
            .setTitle('📥 Registro de Entrada')
            .setColor(0x00FF00)
            .addFields(
                { name: 'Colaborador', value: `<@${userId}>` },
                { name: 'Horário de Entrada', value: new Date(entryTime).toLocaleString('pt-BR') }
            )
            .setTimestamp();

        await this.sendLog(embed);
    }

    async logExit(userId, entryTime, exitTime, duration) {
        const embed = new EmbedBuilder()
            .setTitle('📤 Registro de Saída')
            .setColor(0xFF0000)
            .addFields(
                { name: 'Colaborador', value: `<@${userId}>` },
                { name: 'Horário de Entrada', value: new Date(entryTime).toLocaleString('pt-BR') },
                { name: 'Horário de Saída', value: new Date(exitTime).toLocaleString('pt-BR') },
                { name: 'Duração do Turno', value: `${duration.toFixed(2)} horas` }
            )
            .setTimestamp();

        await this.sendLog(embed);
    }

    async logVacationRequest(userId, startDate, endDate, reason) {
        const embed = new EmbedBuilder()
            .setTitle('🏖️ Nova Solicitação de Férias')
            .setColor(0x0099FF)
            .addFields(
                { name: 'Colaborador', value: `<@${userId}>` },
                { name: 'Período', value: `${startDate} até ${endDate}` },
                { name: 'Motivo', value: reason }
            )
            .setTimestamp();

        await this.sendLog(embed);
    }

    async logVacationDecision(userId, startDate, endDate, status, decidedBy) {
        const embed = new EmbedBuilder()
            .setTitle(`🏖️ Solicitação de Férias ${status}`)
            .setColor(status === 'aprovada' ? 0x00FF00 : 0xFF0000)
            .addFields(
                { name: 'Colaborador', value: `<@${userId}>` },
                { name: 'Período', value: `${startDate} até ${endDate}` },
                { name: 'Status', value: status },
                { name: 'Decidido por', value: `<@${decidedBy}>` }
            )
            .setTimestamp();

        await this.sendLog(embed);
    }

    async logPasswordChange(userId, isReset = false) {
        const embed = new EmbedBuilder()
            .setTitle('🔑 Alteração de Senha')
            .setColor(0xFFA500)
            .addFields(
                { name: 'Colaborador', value: `<@${userId}>` },
                { name: 'Tipo', value: isReset ? 'Redefinição de senha' : 'Alteração de senha' }
            )
            .setTimestamp();

        await this.sendLog(embed);
    }

    async logWeeklySummary(userId, weeklyHours, totalSessions) {
        const embed = new EmbedBuilder()
            .setTitle('📊 Resumo Semanal')
            .setColor(0x9400D3)
            .addFields(
                { name: 'Colaborador', value: `<@${userId}>` },
                { name: 'Horas Trabalhadas', value: `${weeklyHours.toFixed(2)} horas` },
                { name: 'Total de Sessões', value: `${totalSessions} sessões` }
            )
            .setTimestamp();

        await this.sendLog(embed);
    }

    async logError(error, context) {
        const embed = new EmbedBuilder()
            .setTitle('⚠️ Erro no Sistema')
            .setColor(0xFF0000)
            .addFields(
                { name: 'Contexto', value: context },
                { name: 'Erro', value: error.message },
                { name: 'Stack', value: error.stack ? error.stack.slice(0, 1000) : 'Não disponível' }
            )
            .setTimestamp();

        await this.sendLog(embed);
    }
}

module.exports = ActivityLogger;