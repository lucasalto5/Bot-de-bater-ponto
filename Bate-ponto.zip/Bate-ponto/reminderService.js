const { EmbedBuilder } = require('discord.js');
const fs = require('fs/promises');
const path = require('path');

class ReminderService {
    constructor(client) {
        this.client = client;
        this.configPath = path.join(__dirname, 'settings.json');
        this.reminderChannelId = null;
        this.initialize();
    }

    async initialize() {
        try {
            const config = await this.readConfig();
            this.reminderChannelId = config.CHANNELS.REMINDER;
        } catch (error) {
            console.error('Erro ao inicializar reminder service:', error);
        }
    }

    async readConfig() {
        const data = await fs.readFile(this.configPath, 'utf8');
        return JSON.parse(data);
    }

    async updateChannel() {
        try {
            const config = await this.readConfig();
            this.reminderChannelId = config.CHANNELS.REMINDER;
        } catch (error) {
            console.error('Erro ao atualizar canal de lembretes:', error);
        }
    }

    async getChannel() {
        await this.updateChannel();
        let channel = this.client.channels.cache.get(this.reminderChannelId);
        
        if (!channel) {
            try {
                channel = await this.client.channels.fetch(this.reminderChannelId);
            } catch (error) {
                console.error('Erro ao buscar o canal de lembretes:', error);
                return null;
            }
        }
        return channel;
    }

    async enviarLembretes() {
        const agora = new Date();
        const hora = agora.getHours();
        const minuto = agora.getMinutes();

        const canal = await this.getChannel();
        if (!canal) return;

        if (hora === 16 && minuto === 47) {
            const embedEntrada = new EmbedBuilder()
                .setTitle('Lembrete de Entrada')
                .setDescription('Bom dia! Não esqueça de bater o ponto de entrada.')
                .setColor(0x00AE86)
                .setTimestamp();

            await canal.send({ embeds: [embedEntrada] });
        }

        if (hora === 18 && minuto === 0) {
            const embedSaida = new EmbedBuilder()
                .setTitle('Lembrete de Saída')
                .setDescription('Boa noite! Lembre-se de bater o ponto de saída.')
                .setColor(0xFF5733)
                .setTimestamp();

            await canal.send({ embeds: [embedSaida] });
        }
    }
}

module.exports = ReminderService;