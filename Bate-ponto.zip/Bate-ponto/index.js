const { 
  Client, 
  GatewayIntentBits, 
  EmbedBuilder, 
  ActionRowBuilder, 
  ButtonBuilder, 
  ButtonStyle, 
  ModalBuilder, 
  TextInputBuilder, 
  TextInputStyle 
} = require('discord.js');
const fs = require('fs');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds, 
    GatewayIntentBits.GuildMessages, 
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.DirectMessages
  ]
});


const ActivityLogger = require('./logs.js');
const settings = require('./settings.json');

let maintenanceMode = false;
const logger = new ActivityLogger(client, settings.CHANNELS.LOGS);
const REMINDER_CHANNEL_ID = settings.CHANNELS.REMINDER;
const DATA_FILE = settings.FILES.USER_DATA;
const PASSWORD_FILE = settings.FILES.PASSWORDS;
const VACATION_FILE = settings.FILES.VACATION;
const TOKEN = settings.BOT_TOKEN;
const ADMIN_ROLE_ID = settings.ROLES.ADMIN;

const EMOJIS = require('./emojis.js'); // Arquivo de emojis


let userData = {};
let passwords = {};
let vacationRequests = {};

if (fs.existsSync(DATA_FILE)) {  
  userData = JSON.parse(fs.readFileSync(DATA_FILE));
}
if (fs.existsSync(PASSWORD_FILE)) {
  passwords = JSON.parse(fs.readFileSync(PASSWORD_FILE));
}
if (fs.existsSync(VACATION_FILE)) {
  vacationRequests = JSON.parse(fs.readFileSync(VACATION_FILE));
}

function saveData() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(userData, null, 2));
}

function savePasswords() {
  fs.writeFileSync(PASSWORD_FILE, JSON.stringify(passwords, null, 2));
}

function saveVacationRequests() {
  fs.writeFileSync(VACATION_FILE, JSON.stringify(vacationRequests, null, 2));
}

const ReminderService = require('./reminderService.js');



// Após inicializar o client
const reminderService = new ReminderService(client);

// Configurar o intervalo de verificação
setInterval(() => reminderService.enviarLembretes(), 60 * 1000);

function calculateHours(userId) {
  const now = new Date();
  const sessions = userData[userId]?.sessions || [];
  
  const weekStart = new Date(now.setDate(now.getDate() - now.getDay()));
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  
  let weeklyHours = 0;
  let monthlyHours = 0;
  
  sessions.forEach(session => {
    const sessionDate = new Date(session.start);
    if (sessionDate >= weekStart) {
      weeklyHours += session.duration;
    }
    if (sessionDate >= monthStart) {
      monthlyHours += session.duration;
    }
  });
  
  return {
    weekly: weeklyHours.toFixed(2),
    monthly: monthlyHours.toFixed(2)
  };
}


// Load user data from file
if (fs.existsSync(DATA_FILE)) {
  userData = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
}

// Save user data to file
function saveUserData() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(userData, null, 2));
}

// Calculate hours worked
function calculateHours(userId) {
  const now = new Date();
  const sessions = userData[userId]?.sessions || [];
  
  const weekStart = new Date(now.setDate(now.getDate() - now.getDay()));
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  
  let weeklyHours = 0;
  let monthlyHours = 0;
  
  sessions.forEach(session => {
    const sessionDate = new Date(session.start);
    if (sessionDate >= weekStart) {
      weeklyHours += session.duration;
    }
    if (sessionDate >= monthStart) {
      monthlyHours += session.duration;
    }
  });
  
  return {
    weekly: weeklyHours.toFixed(2),
    monthly: monthlyHours.toFixed(2)
  };
}

// Calculate user ranking
function calculateUserRanking() {
  const userRankings = [];
  
  for (const [userId, data] of Object.entries(userData)) {
    let totalHours = 0;
    
    if (data.sessions) {
      totalHours = data.sessions.reduce((acc, session) => acc + (session.duration || 0), 0);
    }
    
    if (data.currentSession) {
      const currentDuration = (new Date() - new Date(data.currentSession.start)) / (1000 * 60 * 60);
      totalHours += currentDuration;
    }
    
    userRankings.push({
      userId,
      totalHours: parseFloat(totalHours.toFixed(2))
    });
  }
  
  return userRankings.sort((a, b) => b.totalHours - a.totalHours).slice(0, 5);
}


const blacklistFile = './blacklist.json';
let blacklist = [];

if (fs.existsSync(blacklistFile)) {
  blacklist = JSON.parse(fs.readFileSync(blacklistFile));
}

function saveBlacklist() {
  fs.writeFileSync(blacklistFile, JSON.stringify(blacklist, null, 2));
}

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  const userId = interaction.user.id;

  if (blacklist.includes(userId)) {
    await interaction.reply({ content: 'Você está na blacklist e não pode interagir com o bot.', ephemeral: true });
    return;
  }
  

  if (interaction.customId === 'blacklist') {
    const blacklistEmbed = new EmbedBuilder()
      .setTitle('Blacklist')
      .setDescription('Usuários na blacklist:')
      .setColor(0xFF0000)
      .setTimestamp();

    if (blacklist.length === 0) {
      blacklistEmbed.setDescription('Nenhum usuário na blacklist.');
    } else {
      blacklistEmbed.setDescription(blacklist.map(id => `<@${id}>`).join('\n'));
    }

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('addToBlacklist')
        .setLabel('Adicionar')     
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('removeFromBlacklist')
        .setLabel('Remover')
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.reply({ embeds: [blacklistEmbed], components: [buttons], ephemeral: true });
  }

  if (interaction.customId === 'addToBlacklist') {
    const modal = new ModalBuilder()
      .setCustomId('addBlacklistModal')
      .setTitle('Adicionar à Blacklist');

    const userIdInput = new TextInputBuilder()
      .setCustomId('userIdInput')
      .setLabel('ID do Usuário')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const actionRow = new ActionRowBuilder().addComponents(userIdInput);
    modal.addComponents(actionRow);

    await interaction.showModal(modal);
  }

  if (interaction.customId === 'removeFromBlacklist') {
    const modal = new ModalBuilder()
      .setCustomId('removeBlacklistModal')
      .setTitle('Remover da Blacklist');

    const userIdInput = new TextInputBuilder()
      .setCustomId('userIdInput')
      .setLabel('ID do Usuário')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const actionRow = new ActionRowBuilder().addComponents(userIdInput);
    modal.addComponents(actionRow);

    await interaction.showModal(modal);
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  if (interaction.customId === 'addBlacklistModal') {
    const userId = interaction.fields.getTextInputValue('userIdInput');
    if (!blacklist.includes(userId)) {
      blacklist.push(userId);
      saveBlacklist();
      await interaction.reply({ content: `Usuário <@${userId}> adicionado à blacklist.`, ephemeral: true });
    } else {
      await interaction.reply({ content: `Usuário <@${userId}> já está na blacklist.`, ephemeral: true });
    }
  }

  if (interaction.customId === 'removeBlacklistModal') {
    const userId = interaction.fields.getTextInputValue('userIdInput');
    const index = blacklist.indexOf(userId);
    if (index !== -1) {
      blacklist.splice(index, 1);
      saveBlacklist();
      await interaction.reply({ content: `Usuário <@${userId}> removido da blacklist.`, ephemeral: true });
    } else {
      await interaction.reply({ content: `Usuário <@${userId}> não está na blacklist.`, ephemeral: true });
    }
  }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  if (interaction.customId === 'horas') {
    const hours = calculateHours(interaction.user.id);
    const hoursEmbed = new EmbedBuilder()
      .setTitle('Horas Trabalhadas')
      .setColor(0x00AE86)
      .addFields(
        { name: 'Horas esta Semana', value: `${hours.weekly} horas` },
        { name: 'Horas este Mês', value: `${hours.monthly} horas` }
      )
      .setTimestamp();

    await interaction.reply({ embeds: [hoursEmbed], ephemeral: true });
  }

  if (interaction.customId === 'ferias') {
    const modal = new ModalBuilder()
      .setCustomId('vacationRequest')
      .setTitle('Solicitar Férias');

    const startDateInput = new TextInputBuilder()
      .setCustomId('startDate')
      .setLabel('Data de Início (DD/MM/YYYY)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const endDateInput = new TextInputBuilder()
      .setCustomId('endDate')
      .setLabel('Data de Término (DD/MM/YYYY)')
      .setStyle(TextInputStyle.Short)
      .setRequired(true);

    const reasonInput = new TextInputBuilder()
      .setCustomId('reason')
      .setLabel('Motivo')
      .setStyle(TextInputStyle.Paragraph)
      .setRequired(true);

    const row1 = new ActionRowBuilder().addComponents(startDateInput);
    const row2 = new ActionRowBuilder().addComponents(endDateInput);
    const row3 = new ActionRowBuilder().addComponents(reasonInput);

    modal.addComponents(row1, row2, row3);
    await interaction.showModal(modal);
  }

  if (interaction.customId.startsWith('vacation_')) {
    const [, action, requestId] = interaction.customId.split('_');
    const request = vacationRequests[requestId];
    
    if (!request) {
      await interaction.reply({ content: 'Solicitação não encontrada.', ephemeral: true });
      return;
    }

    const isApproved = action === 'approve';
    const status = isApproved ? 'aprovada' : 'negada';
    

    request.status = status;
    request.decidedBy = interaction.user.id;
    request.decidedAt = new Date().toISOString();
    saveVacationRequests();

    await logger.logVacationDecision(
      request.userId,
      request.startDate,
      request.endDate,
      status,
      interaction.user.id
  );

    // Notify 
    const notificationEmbed = new EmbedBuilder()
      .setTitle(`Solicitação de Férias ${status.charAt(0).toUpperCase() + status.slice(1)}`)
      .setColor(isApproved ? 0x00FF00 : 0xFF0000)
      .addFields(
        { name: 'Período', value: `${request.startDate} até ${request.endDate}` },
        { name: 'Status', value: status },
        { name: 'Decidido por', value: `<@${request.decidedBy}>` }
      )
      .setTimestamp();

    try {
      const requester = await client.users.fetch(request.userId);
      await requester.send({ embeds: [notificationEmbed] });
    } catch (error) {
      console.error('Error sending DM:', error);
    }

    await interaction.update({ 
      content: `Solicitação de férias ${status}!`,
      components: [] 
    });
  }
});


client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  if (interaction.customId === 'vacationRequest') {
    const startDate = interaction.fields.getTextInputValue('startDate');
    const endDate = interaction.fields.getTextInputValue('endDate');
    const reason = interaction.fields.getTextInputValue('reason');
    
    const requestId = Date.now().toString();
    const request = {
      id: requestId,
      userId: interaction.user.id,
      startDate,
      endDate,
      reason,
      status: 'pending',
      requestedAt: new Date().toISOString()
    };

    vacationRequests[requestId] = request;
    saveVacationRequests();


    const requestEmbed = new EmbedBuilder()
      .setTitle('Nova Solicitação de Férias')
      .setColor(0x0099FF)
      .addFields(
        { name: 'Colaborador', value: `<@${interaction.user.id}>` },
        { name: 'Período', value: `${startDate} até ${endDate}` },
        { name: 'Motivo', value: reason }
      )
      .setTimestamp();

    const buttons = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`vacation_approve_${requestId}`)
        .setLabel('Aprovar')
        .setStyle(ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId(`vacation_deny_${requestId}`)
        .setLabel('Negar')
        .setStyle(ButtonStyle.Danger)
    );

    const channel = await client.channels.fetch(REMINDER_CHANNEL_ID);
    await channel.send({ embeds: [requestEmbed], components: [buttons] });
    
    await interaction.reply({ 
      content: 'Sua solicitação de férias foi enviada com sucesso!', 
      ephemeral: true 
    });
  }
});

let embedMessage = null;

client.once('ready', () => {
  console.log(`Bot ${client.user.tag} está online!`);
});

// Command !ponto:
client.on('messageCreate', async (message) => {
  if(message.author.bot) return;

  if(message.content.startsWith('!ponto')) {

    await message.delete();
    
    const embed = createEmbed();
    const row = createActionRow();


    embedMessage = await message.channel.send({ 
      embeds: [embed], 
      components: [row] 
    });
  }
});

// embed 
function createEmbed() {
  const embed = new EmbedBuilder()
    .setTitle('Registro de Ponto')
    .setDescription('Selecione uma opção abaixo:')
    .setColor(0x00AE86)
    .setTimestamp();

  let emTurno = '';
  for (const [userId, registro] of Object.entries(userData)) {
    if (registro.currentSession) {
      const duracao = ((new Date() - new Date(registro.currentSession.start)) / (1000 * 60 * 60)).toFixed(2);
      emTurno += `<@${userId}> está em turno`;
    }
  }
  embed.addFields({ name: 'Em Turno', value: emTurno || 'Ninguém está em turno no momento.' });

  return embed;
}

// buttons
function createActionRow() {
  return new ActionRowBuilder().addComponents(
      new ButtonBuilder()
          .setCustomId('entrada')
          .setLabel('Entrada')
          .setEmoji(EMOJIS.ENTRADA)  
          .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
          .setCustomId('saida')
          .setLabel('Saída')
          .setEmoji(EMOJIS.SAIDA)   
          .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
          .setCustomId('opcoes')
          .setLabel('Opções')
          .setEmoji(EMOJIS.OPCOES) 
          .setStyle(ButtonStyle.Primary)
  );
}

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  if (interaction.customId === 'opcoes') {
    const menuEmbed = new EmbedBuilder()
      .setTitle('Menu Principal')
      .setDescription('Escolha uma das opções abaixo:')
      .setColor(0x00AE86)
      .setTimestamp();

    const menuRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('menu')
        .setLabel('Menu')
        .setEmoji(EMOJIS.MENU)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('administracao')
        .setLabel('Administração')
        .setEmoji(EMOJIS.ADMINISTRACAO)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('suporte')
        .setLabel('Suporte')
        .setEmoji(EMOJIS.SUPORE)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('status')
        .setLabel('Status')
        .setEmoji(EMOJIS.STATUS)
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.reply({
      embeds: [menuEmbed],
      components: [menuRow],
      ephemeral: true 
    });
  }

  if (interaction.customId === 'status') {
    const botInfoEmbed = new EmbedBuilder()
      .setTitle('Informações do Bot')
      .setDescription('Se quiser tirar alguma duvida sobre o bot, entre em contato com o criador: informacoes abaixo:')
      .addFields(
        { name: 'Nome e Versão', value: 'TimeSync v0.5', inline: true },
        { name: 'Data de Criação', value: '15/02/2025', inline: true },
        { name: 'Ping ', value: `${client.ws.ping}ms`, inline: true },
        { name: 'Comandos', value: '!ponto', inline: true },
        { name: 'Criador', value: 'DC: rogerinhoxr', inline: true },
        { name: 'Uptime ', value: `${Math.floor(client.uptime / 1000)}s`, inline: true },
        { name: 'Tecnologias', value: 'JavaScript, Node.js, Discord.js', inline: true }
      )
      .setColor(0x00AE86)
      .setTimestamp();

    await interaction.reply({
      embeds: [botInfoEmbed],
      ephemeral: true
    });
  }

  if (interaction.customId === 'menu') {
    const optionsEmbed = createOptionsEmbed();
    const optionsRow = createOptionsActionRow();

    await interaction.update({
      embeds: [optionsEmbed],
      components: [optionsRow],
      ephemeral: true 
    });
  }

  if (interaction.customId === 'administracao') {
    if (!interaction.member.roles.cache.has(ADMIN_ROLE_ID)) {
      return interaction.reply({
        content: 'Você não tem permissão para acessar o menu de administração.',
        ephemeral: true
      });
    }

    const adminEmbed = new EmbedBuilder()
      .setTitle('Administração')
      .setDescription('Escolha uma das opções administrativas abaixo:')
      .setColor(0xFF5733)
      .setTimestamp();

    const adminRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('advanced')
        .setLabel('Avançado')
        .setEmoji(EMOJIS.ADVANCED)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('maintenanceMode')
        .setLabel('Manutenção')
        .setEmoji(EMOJIS.OPCOES)
        .setDisabled(true)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('blacklist')
        .setLabel('Blacklist')
        .setEmoji(EMOJIS.MODDER)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('backToMain')
        .setLabel('Voltar')
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.update({
      embeds: [adminEmbed],
      components: [adminRow],
      ephemeral: true 
    });
    

  } else if (interaction.customId === 'backToMain') {
    const menuEmbed = new EmbedBuilder()
      .setTitle('Menu Principal')
      .setDescription('Escolha uma das opções abaixo:')
      .setColor(0x00AE86)
      .setTimestamp();

    const menuRow = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId('menu')
        .setLabel('Menu')
        .setEmoji(EMOJIS.MENU)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('administracao')
        .setLabel('Administração')
        .setEmoji(EMOJIS.ADMINISTRACAO)
        .setStyle(ButtonStyle.Secondary),
      new ButtonBuilder()
        .setCustomId('suporte')
        .setLabel('Suporte')
        .setEmoji(EMOJIS.SUPORE)
        .setStyle(ButtonStyle.Primary),
      new ButtonBuilder()
        .setCustomId('status')
        .setLabel('Status')
        .setEmoji(EMOJIS.STATUS)
        .setStyle(ButtonStyle.Secondary)
    );

    await interaction.update({
      embeds: [menuEmbed],
      components: [menuRow],
      ephemeral: true 
    });

    
  } else if (interaction.customId === 'maintenanceMode') {
    maintenanceMode = !maintenanceMode;
    await interaction.reply({ content: `Esse modo esta em desenvolvimento.`, ephemeral: true });
  } else if (interaction.customId === 'suporte') {
  maintenanceMode = !maintenanceMode;
  await interaction.reply({ content: `Qualquer duvida entre em contato com o criador: DC: rogerinhoxr`, ephemeral: true });
}
});

function createOptionsEmbed() {
  return new EmbedBuilder()
    .setTitle('Opções Adicionais')
    .setDescription('Selecione uma das opções abaixo:')
    .setColor(0x00AE86)
    .setTimestamp();
}

function createOptionsActionRow() {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setCustomId('horas')
      .setLabel('Horas Trabalhadas')
      .setEmoji(EMOJIS.HORAS)
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('ferias')
      .setLabel('Solicitar Férias')
      .setEmoji(EMOJIS.FERIAS)
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('ranking')
      .setLabel('Top 5 Ranking')
      .setEmoji(EMOJIS.RANK)
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('backToMain')
      .setLabel('Voltar')
      .setStyle(ButtonStyle.Secondary)
  );
}

const advancedHandler = require('./advancedSettingsHandler.js');

client.on('interactionCreate', async interaction => {
    if (interaction.isButton()) {
        if (interaction.customId === 'advanced') {
            await advancedHandler.handleAdvancedButton(interaction);
        } else if (interaction.customId.startsWith('edit_')) {
            await advancedHandler.handleEditButtons(interaction);
        }
    } else if (interaction.isModalSubmit() && interaction.customId.startsWith('modal_')) {
        await advancedHandler.handleModalSubmit(interaction);
    }
});

client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton() || interaction.customId !== 'ranking') return;
  
  const rankings = calculateUserRanking();
  
  const rankingEmbed = new EmbedBuilder()
      .setTitle('Top 5 - Ranking de Horas')
      .setColor(0xFFD700)
      .setTimestamp();
  
  if (rankings.length === 0) {
      rankingEmbed.setDescription('Ainda não há registros de horas.');
  } else {
      const description = await Promise.all(rankings.map(async (rank, index) => {
          try {
              const user = await client.users.fetch(rank.userId);
              const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '🎖️';
              return `${medal} **${index + 1}º** ${user.username} - ${rank.totalHours} horas`;
          } catch (error) {
              console.error(`Erro ao buscar usuário ${rank.userId}:`, error);
              return `${index + 1}º Usuário não encontrado - ${rank.totalHours} horas`;
          }
      }));
      
      rankingEmbed.setDescription(description.join('\n'));
  }
  
  await interaction.reply({
      embeds: [rankingEmbed],
      ephemeral: true
  });
});

// Handle button interactions
client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  const userId = interaction.user.id;

  if (interaction.customId === 'entrada' || interaction.customId === 'saida') {
    if (!passwords[userId]) {
      const modal = new ModalBuilder()
        .setCustomId('setPassword')
        .setTitle('Definir Senha');

      const passwordInput = new TextInputBuilder()
        .setCustomId('passwordInput')
        .setLabel('Digite sua nova senha')
        .setStyle(TextInputStyle.Short);

      const actionRow = new ActionRowBuilder().addComponents(passwordInput);
      modal.addComponents(actionRow);

      await interaction.showModal(modal);
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`verifyPassword-${interaction.customId}`)
      .setTitle('Verificar Senha');

    const passwordInput = new TextInputBuilder()
      .setCustomId('passwordInput')
      .setLabel('Digite sua senha ou "Esqueci Senha"')
      .setStyle(TextInputStyle.Short);

    const actionRow = new ActionRowBuilder().addComponents(passwordInput);
    modal.addComponents(actionRow);

    await interaction.showModal(modal);
  }
});


client.on('interactionCreate', async (interaction) => {
  if (!interaction.isModalSubmit()) return;

  const userId = interaction.user.id;

  if (interaction.customId === 'setPassword') {
    const password = interaction.fields.getTextInputValue('passwordInput');
    passwords[userId] = password;
    savePasswords();
    await logger.logPasswordChange(userId, true); 
    await interaction.reply({ content: 'Senha registrada com sucesso!', ephemeral: true });
}


  if (interaction.customId.startsWith('verifyPassword')) {
    const password = interaction.fields.getTextInputValue('passwordInput').toLowerCase();
    const action = interaction.customId.split('-')[1];

    if (password === 'esqueci senha') {
      const embed = new EmbedBuilder()
        .setTitle('Recuperação de Senha')
        .setDescription('Escolha uma opção abaixo:')
        .setColor(0xFF5733)
        .addFields(
          { name: '1. Redefinir Senha', value: 'Clique para redefinir sua senha.' },
          { name: '2. Enviar Senha no Privado', value: 'Clique para receber sua senha atual no privado.' }
        );

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId('redefinirSenha')
          .setLabel('Redefinir Senha')
          .setEmoji(EMOJIS.REDEFINIR)
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('enviarSenhaPrivado')
          .setLabel('Enviar Senha no Privado')
          .setEmoji(EMOJIS.SENHA)
          .setStyle(ButtonStyle.Secondary)
      );

      await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
    } else if (passwords[userId] === password) {
      if (action === 'entrada') {
        if (!userData[userId]) userData[userId] = { sessions: [] };
        userData[userId].currentSession = { start: new Date() };
        saveData();
        await logger.logEntry(userId, userData[userId].currentSession.start);
        await interaction.reply({ content: 'Entrada registrada com sucesso!', ephemeral: true });
    }
    if (action === 'saida') {
      const registro = userData[userId];
      if (registro && registro.currentSession) {
          registro.currentSession.end = new Date();
          const duracao = (registro.currentSession.end - registro.currentSession.start) / (1000 * 60 * 60);
          await logger.logExit(userId, registro.currentSession.start, registro.currentSession.end, duracao);
          registro.sessions.push(registro.currentSession);
          delete registro.currentSession;
          saveData();
          await interaction.reply({ content: `Saída registrada com sucesso! Você trabalhou ${duracao.toFixed(2)} horas.`, ephemeral: true });
        } else {
          await interaction.reply({ content: 'Nenhuma entrada encontrada. Registre sua entrada primeiro!', ephemeral: true });
        }
      }
      if (embedMessage) {
        const updatedEmbed = createEmbed();
        await embedMessage.edit({ embeds: [updatedEmbed] });
      }
    } else {
      await interaction.reply({ content: 'Senha incorreta. Tente novamente.', ephemeral: true });
    }
  }
});


client.on('interactionCreate', async (interaction) => {
  if (!interaction.isButton()) return;

  const userId = interaction.user.id;

  if (interaction.customId === 'redefinirSenha') {
    const modal = new ModalBuilder()
      .setCustomId('setPassword')
      .setTitle('Redefinir Senha');

    const passwordInput = new TextInputBuilder()
      .setCustomId('passwordInput')
      .setLabel('Digite sua nova senha')
      .setStyle(TextInputStyle.Short);

    const actionRow = new ActionRowBuilder().addComponents(passwordInput);
    modal.addComponents(actionRow);

    await interaction.showModal(modal);
  }

  if (interaction.customId === 'enviarSenhaPrivado') {
    const userPassword = passwords[userId];
    if (userPassword) {
      const embed = new EmbedBuilder()
      .setColor('#0099ff')
      .setTitle('Sua Senha Atual')
      .setDescription(`||${userPassword}||`) 
      .setFooter({ text: 'Guarde sua senha com segurança!' });
  
  await interaction.user.send({ embeds: [embed] });
      await interaction.reply({ content: 'Sua senha foi enviada no privado.', ephemeral: true });
    } else {
      await interaction.reply({ content: 'Nenhuma senha encontrada para este usuário.', ephemeral: true });
    }
  }
});





async function logWeeklySummary() {
  for (const [userId, data] of Object.entries(userData)) {
      const hours = calculateHours(userId);
      const totalSessions = data.sessions ? data.sessions.length : 0;
      
      await logger.logWeeklySummary(
          userId,
          parseFloat(hours.weekly),
          totalSessions
      );
  }
}


setInterval(logWeeklySummary, 7 * 24 * 60 * 60 * 1000); // Executa a cada 7 dias

// Adiciona um listener para erros não capturados (síncronos)
process.on('uncaughtException', async (error) => {
  console.error('Erro não capturado (uncaughtException):', error);
  await logger.logError(error, 'Erro não capturado');
});

process.on('unhandledRejection', async (reason, promise) => {
  console.error('Rejeição não tratada (unhandledRejection):', reason);
  await logger.logError(reason, 'Rejeição não tratada');
});

// Inicia o bot com tratamento de erros
client.login(TOKEN)
  .then(() => {
      console.log('Bot conectado com sucesso!');
  })
  .catch((error) => {
      console.error('Erro ao conectar o bot:', error);
      // Reconecta o bot em caso de falha na conexão
      setTimeout(() => {
          console.log('Tentando reconectar o bot...');
          client.login(TOKEN);
      }, 5000); // Tenta reconectar após 5 segundos
  });

// Mantém o bot ativo mesmo em caso de erros
process.on('exit', (code) => {
  console.log(`Processo encerrado com código ${code}. Reiniciando...`);
  // Reinicia o bot
  client.login(TOKEN);
});